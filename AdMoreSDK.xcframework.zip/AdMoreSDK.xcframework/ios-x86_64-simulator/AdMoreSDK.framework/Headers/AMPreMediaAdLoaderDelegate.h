//
//  AMPreMediaAdLoaderDelegate.h
//  AdMoreSDK
//
//  Created by Aaron on 2021/5/16.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

// 前贴图片广告回调
@protocol AMPreMediaAdLoaderDelegate <NSObject>

@optional

//广告加载完成回调
//@param preAdvtView 视图实例
//@param error 错误信息
- (void)am_preAdvtAdLoaded:(UIView *_Nullable)preAdvtView
                      error:(NSError * _Nullable)error;


//广告点击回调
//@param preAdvtView 视图实例
//@param deepLink 可能为空,当需要支持deeplink打开方式时,值不为空
- (void)am_preAdvtViewDidClick:(UIView * _Nonnull)preAdvtView isDeeplink:(NSString *_Nullable)deepLink;


//广告曝光回调
//@param preAdvtView 视图实例
- (void)am_preAdvtWillExpose:(UIView * _Nonnull)preAdvtView;
 

//广告详情页将要展示回调
//@param preAdvtView 视图实例
- (void)am_preAdvtDetailViewWillPresent:(UIView * _Nonnull)preAdvtView;
 

//广告详情页退出回调
//@param preAdvtView 视图实例
- (void)am_preAdvtDetailViewClosed:(UIView *_Nonnull)preAdvtView;


//广告播放完成回调
//@param preAdvtView 视图实例
- (void)am_preAdvtPlayFinish:(UIView *_Nonnull)preAdvtView;


//广告倒计时
//@param countDown 广告剩余时间
- (void)am_preAdvtCountDown:(NSInteger)countDown;

@end


NS_ASSUME_NONNULL_END
