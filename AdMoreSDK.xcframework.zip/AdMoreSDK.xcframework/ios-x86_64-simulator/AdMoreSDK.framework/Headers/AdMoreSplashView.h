//
//  AdMoreSplashView.h
//  AdMoreSDK
//
//  Created by Aaron on 2021/5/15.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@class AdMoreSplashView;

NS_ASSUME_NONNULL_BEGIN


@protocol AdMoreSplashViewDelegate <NSObject>

@optional
/**
 *  开屏广告成功展示
 */
- (void)am_splashAdSuccessPresentScreen:(AdMoreSplashView *)splashAdLoader;

/**
 *  开屏广告素材加载成功
 */
- (void)am_splashAdDidLoad:(AdMoreSplashView *)splashAdLoader;

/**
 *  开屏广告展示失败
 */
- (void)am_splashAdFailToPresent:(AdMoreSplashView *)splashAdLoader withError:(NSError *)error;

/**
 *  应用进入后台时回调
 *  详解: 当点击下载应用时会调用系统程序打开，应用切换到后台
 */
- (void)am_splashAdApplicationWillEnterBackground:(AdMoreSplashView *)splashAdLoader;

/**
 *  开屏广告曝光回调
 */
- (void)am_splashAdExposured:(AdMoreSplashView *)splashAdLoader;

/**
 *  开屏广告点击回调
 */
- (void)am_splashAdClicked:(AdMoreSplashView *)splashAdLoader;

/**
 *  开屏广告将要关闭回调
 */
- (void)am_splashAdWillClosed:(AdMoreSplashView *)splashAdLoader;

/**
 *  开屏广告关闭回调
 */
- (void)am_splashAdClosed:(AdMoreSplashView *)splashAdLoader;

/**
 *  开屏广告点击以后即将弹出全屏广告页
 */
- (void)am_splashAdWillPresentFullScreenModal:(AdMoreSplashView *)splashAdLoader;

/**
 *  开屏广告点击以后弹出全屏广告页
 */
- (void)am_splashAdDidPresentFullScreenModal:(AdMoreSplashView *)splashAdLoader;

/**
 *  点击以后全屏广告页将要关闭
 */
- (void)am_splashAdWillDismissFullScreenModal:(AdMoreSplashView *)splashAdLoader;

/**
 *  点击以后全屏广告页已经关闭
 */
- (void)am_splashAdDidDismissFullScreenModal:(AdMoreSplashView *)splashAdLoader;

/**
 * 开屏广告剩余时间回调
 */
- (void)am_splashAdLifeTime:(NSUInteger)time;

@end

//开屏
@interface AdMoreSplashView : NSObject

- (instancetype)initWithPlaceId:(NSString *)placeId;


//加载广告
- (void)loadAd;

/**
 *  详解：广告展示成功时会回调splashAdSuccessPresentScreen方法，展示失败时会回调splashAdFailToPresent方法
 */
- (void)showAdInWindow:(UIWindow *)window withBottomView:(UIView *)bottomView skipView:(UIView *)skipView;

/**
 *  委托对象
 */
@property (nonatomic,weak)id<AdMoreSplashViewDelegate>delegate;

/**
 *  拉取广告超时时间，默认为3秒
 *  详解：拉取广告超时时间，开发者调用loadAd方法以后会立即展示backgroundImage，然后在该超时时间内，如果广告拉
 *  取成功，则立马展示开屏广告，否则放弃此次广告展示机会。
 */
@property (nonatomic, assign) CGFloat fetchDelay;

/**
 *  开屏广告的背景图片
 *  可以设置背景图片作为开屏加载时的默认背景
 */
@property (nonatomic, strong) UIImage *backgroundImage;

/**
 *  开屏广告的背景色
 *  可以设置开屏图片来作为开屏加载时的默认图片
 */
@property (nonatomic, copy) UIColor *backgroundColor;

@end

NS_ASSUME_NONNULL_END
