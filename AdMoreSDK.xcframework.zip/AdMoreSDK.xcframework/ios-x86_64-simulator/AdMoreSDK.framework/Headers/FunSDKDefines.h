//
//  FunSDKDefines.h
//  FunAdSdk
//
//  Created by 王瑞辰 on 2020/12/10.
//  Copyright © 2020 funshion. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

extern NSString * _Nonnull const PRODUCT_VERSION;
extern NSString * _Nonnull const FPlusVersion;

//Icon的宽高
static const CGFloat OutPutAdViewIconWightAndHeight = 60.0f;
//间距
static const CGFloat Margin = 10.0f;
//关闭按钮的宽高
static const CGFloat CloseButtonWightAndHeight = 20.0f;
//视频或图片的显示高度
static const CGFloat ShowAdAreaHeight = 200.0f;
//模版信息流卡片样式视频宽度
static const CGFloat SmallCardWitdh = 125.0f;
//模版信息流卡片样式视频高度
static const CGFloat SmallCardHeigh = 70.0f;
//模版信息流卡片样式视频高度
static const CGFloat BannerHeigh = 60.0f;

NS_ASSUME_NONNULL_BEGIN

/**
 *  视频播放器状态
 *
 *  播放器只可能处于以下状态中的一种
 *
 */
typedef NS_ENUM(NSUInteger, FSMediaPlayerStatus) {
    FSMediaPlayerStatusInitial = 0,         // 初始状态
    FSMediaPlayerStatusLoading = 1,         // 加载中
    FSMediaPlayerStatusStarted = 2,         // 开始播放
    FSMediaPlayerStatusPaused = 3,          // 用户行为导致暂停
    FSMediaPlayerStatusError = 4,           // 播放出错
    FSMediaPlayerStatusStoped = 5,          // 播放停止
};

typedef NS_ENUM(NSUInteger, FunCloseLocation) {
    //占位
    FunCloseLocationUpperNone = 0,
    //左上
    FunCloseLocationUpperLeft = 1,
    //右上
    FunCloseLocationUpperRight = 2,
    //左下
    FunCloseLocationLowerLeft = 3,
    //右下
    FunCloseLocationLowerRight = 4,
};

///广告来源
typedef NS_ENUM(NSInteger, FunAdSource) {
    ///占位
    FunAdSourceNone = 0,
    ///风行广告
    FunAdSourceFUN = 1,
    ///腾讯（优量汇/广点通）
    FunAdSourceTX = 2,
    ///百度
    FunAdSourceBD = 3,
    ///穿山甲
    FunAdSourceTT = 4,
    ///快手
    FunAdSourceKS = 5
};


///广告类型
typedef NS_ENUM(NSInteger, FunAdADPType) {
    ///占位
    FunAdADPTypeNone = 0,
    ///信息流广告
    FunAdADPTypeFeed = 1,
    ///前贴
    FunAdADPTypeQT = 2,
    ///中帖广告
    FunAdADPTypeZT = 3,
    ///激励广告
    FunAdADPTypeJL = 4
};

/// 广告类型返回字符串的函数
/// @param key FunAdADPType
extern NSString * FunAdADPTypeIdentifier(FunAdADPType key);


/// 根据字符串返回广告类型
/// @param key 字符串类型
extern FunAdSource FunAdSourceTypeIdentifier(NSString *key);


///输出视图样式
typedef NS_ENUM(NSInteger,FunOutPutAdViewStyle) {
    ///占位
    FunOutPutAdViewStyleNone = 0,
    ///带有Icon
    FunOutPutAdViewStyleHaveIcon = 1,
    ///描述在上方
    FunOutPutAdViewStyleDesc = 2,
    ///小卡片
    FunOutPutAdViewStyleSmallCard = 3,
    ///banner
    FunOutPutAdViewStyleBanner = 4,
    ///大图
    FunOutPutAdViewStyleStill = 5,
};



///输出视图样式
typedef NS_ENUM(NSInteger,FunAdOpenType) {
    ///占位
    FunAdOpenTypeNone = 0,
    ///外部Web
    FunAdOpenTypeOuterWeb = 1,
    ///内部Web
    FunAdOpenTypeInnerWeb = 2,
    ///deepLink
    FunAdOpenTypeDeepLink= 3
};

/// 根据字符串返回广告打开类型
/// @param key 字符串类型
extern FunAdOpenType FunAdOpenTypeIdentifier(NSString *key);


///错误码
typedef NS_ENUM(NSInteger, FunErrorType) {
    FunErrorTypeNone = 0,
    ///网络错误
    FunErrorTypeNetError = 3001,
    ///手机无网络
    FunErrorTypeNoNet = 3003,
    ///初始化错误, 包括广告位为空、AppKey为空、ViewController为空
    FunErrorTypeInitError = 4001,
    ///广告位错误
    FunErrorTypeADPError = 4003,
    ///广告未曝光
    FunErrorTypeNoExposure = 4006,
    ///设备不支持
    FunErrorTypeDeviceNoSupport = 4007,
    ///设备方向不支持
    FunErrorTypeDeviceDirectionError = 4008,
    ///请求广告超时
    FunErrorTypeRequestTimeOut = 4011,
    ///没有请求就拉取展示
    FunErrorTypeSystemNoLoaded = 4014,
    ///系统不支持，原生视频模板广告只支持 iOS 9 及以上系统
    FunErrorTypeSystemNoSupport = 4013,
    ///广告已经曝光过，不允许二次展示，请重新拉取
    FunErrorTypeShowSecond = 4015,
    ///外部传入的VC无效
    FunErrorTypeViewControllerError = 4017,
    ///缓存文件在流程中被意外删除
    FunErrorTypeCacheError = 4018,
    ///window为空
    FunErrorTypeWindowNil = 4020,
    ///appId 错误，未正确注册
    FunErrorTypeAppIdEroor = 4021,
    ///没有广告数据
    FunErrorTypeNOAdData = 5000,
    ///后台数据错误
    FunErrorTypeServierDataError = 5001,
    ///视频素材下载失败
    FunErrorTypeDownLoadDataError = 5002,
    ///视频素材播放错误
    FunErrorTypePlarDataError = 5003,
    ///没有合适的广告数据
    FunErrorTypeNOAd = 5004,
    ///广告请求量或者消耗等超过日限额，请第二天再请求广告
    FunErrorTypeExceedTheLimit = 5005,
    ///包名校验非法
    FunErrorTypePackageNameUnlawfulness = 5006,
    ///广告过期，请重新拉取
    FunErrorTypePastDue = 5012,
    ///广告拉取过于频繁，请稍后再试
    FunErrorTypeFrequently = 5013,
    ///当前版本不出广告
    FunErrorTypeNoOutPutAd = 5015,
    ///JSON数据解析失败
    FunErrorTypeJsonError = 5016,
    ///adCount参数非法
    FunErrorTypeAdCountError = 5017,
    ///广告位下线
    FunErrorTypeADPNoLongerShowing = 5018,
    ///广告已下线
    FunErrorTypeAdNoLongerShowing = 5021,
    ///广告加载失败
    FunErrorTypeAdLoadFail = 6001,
    
    ///广告尺寸不合适
    FunErrorTypeAdSizeError = 6002,
    
};


extern NSError * FunErrorStyleIdentifier(FunErrorType key);

#define FUN_DEPRECATED_MSG_ATTRIBUTE(s) __attribute__((deprecated(s)))
#define IPHONE_X \
({BOOL isPhoneX = NO;\
if (@available(iOS 11.0, *)) {\
isPhoneX = [[UIApplication sharedApplication] delegate].window.safeAreaInsets.bottom > 0.0;\
}\
(isPhoneX);})
//适配iPhone11
#define SafeTop (IPHONE_X ? 44 : 20)


#ifndef fun_dispatch_main_async_safe
#define fun_dispatch_main_async_safe(block)\
if (strcmp(dispatch_queue_get_label(DISPATCH_CURRENT_QUEUE_LABEL), dispatch_queue_get_label(dispatch_get_main_queue())) == 0) {\
block();\
} else {\
dispatch_async(dispatch_get_main_queue(), block);\
}
#endif


/// 竖屏底部安全区域
#define FUN_FOOTER_SAFEAREA_HEIGHT \
({CGFloat bottom=0.0;\
if (@available(iOS 11.0, *)) {\
bottom = [[UIApplication sharedApplication] delegate].window.safeAreaInsets.bottom;\
} else { \
bottom=0;\
}\
(bottom);\
})

#define FUN_SCREEN_WIDTH [UIScreen mainScreen].bounds.size.width
#define FUN_SCREEN_HEIGHT [UIScreen mainScreen].bounds.size.height
#define FUN_WeakObj(o)     __weak typeof(o) o##Weak = o;

#define SCREEN_WIDTH      ([UIScreen mainScreen].bounds.size.width < [UIScreen mainScreen].bounds.size.height ? [UIScreen mainScreen].bounds.size.width : [UIScreen mainScreen].bounds.size.height)

#define SCREEN_HEIGHT     ([UIScreen mainScreen].bounds.size.width > [UIScreen mainScreen].bounds.size.height ? [UIScreen mainScreen].bounds.size.width : [UIScreen mainScreen].bounds.size.height)

#define RGBCOLOR(r,g,b) [UIColor colorWithRed:(r)/255.0 green:(g)/255.0 blue:(b)/255.0 alpha:1]
#define RGBACOLOR(r,g,b,a) [UIColor colorWithRed:(r)/255.0 green:(g)/255.0 blue:(b)/255.0 alpha:(a)]
#define HEXCOLOR(hex) [UIColor colorWithRed:((float)((hex & 0xFF0000) >> 16)) / 255.0 green:((float)((hex & 0xFF00) >> 8)) / 255.0 blue:((float)(hex & 0xFF)) / 255.0 alpha:1]

#define Device_Scales   SCREEN_WIDTH/375.0
#define SizeWidth(h)    (h * Device_Scales)

@interface FunSDKDefines : NSObject


@end

NS_ASSUME_NONNULL_END
