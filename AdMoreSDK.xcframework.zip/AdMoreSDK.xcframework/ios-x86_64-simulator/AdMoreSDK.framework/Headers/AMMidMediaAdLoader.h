//
//  AMMidMediaAdLoader.h
//  AdMoreSDK
//
//  Created by Aaron on 2021/5/17.
//

#import <Foundation/Foundation.h>
#import "AMOutPutAdView.h"

NS_ASSUME_NONNULL_BEGIN

@protocol AMUnifieBetweenAdDelegate <NSObject>

/// 广告数据回调
/// @param unifieBetweenAdViewArray 视图数组
/// @param error 错误信息
- (void)am_unifieBetweenAdLoaded:(NSArray<AMOutPutAdView *> * _Nullable)unifieBetweenAdViewArray error:(NSError * _Nullable)error;

@end

//中帖广告
@interface AMMidMediaAdLoader : NSObject

/// 代理指针
@property (nonatomic, weak)id<AMUnifieBetweenAdDelegate> delegate;

/// 输出视图的样式,此版本只提供两种Style,请在loadAd之前调用
@property (nonatomic, assign)FunOutPutAdViewStyle outPutAdViewStyle;

/// 初始化广告
/// @param placeId 广告类型
- (instancetype)initWithPlaceId:(NSString *)placeId;

/// 获取广告
- (void)loadAd;

@end

NS_ASSUME_NONNULL_END
