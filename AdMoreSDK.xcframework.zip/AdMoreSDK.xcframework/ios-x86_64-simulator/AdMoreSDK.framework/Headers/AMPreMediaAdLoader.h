//
//  AMPreMediaAdLoader.h
//  AdMoreSDK
//
//  Created by Aaron on 2021/5/16.
//

#import <Foundation/Foundation.h>
#import "AMPreMediaAdLoaderDelegate.h"
#import "AMInterstitialAdLoaderDelegate.h"
NS_ASSUME_NONNULL_BEGIN

@interface AMPreMediaAdLoader : NSObject

// 实现视频和图片前贴需要实现
@property (nonatomic,weak)id<AMPreMediaAdLoaderDelegate>delegate;

// 插屏式前贴需要实现
@property (nonatomic,weak)id<AMInterstitialAdLoaderDelegate>interstitialDelegate;

//  前贴视频广告是否静音 默认YES
@property (nonatomic,assign)BOOL videoMuted;

//当前广告展示的controller
//必填,不然无法触发点击事件
@property (nonatomic,weak)UIViewController *viewController;

//是否展示默认的倒计时 默认为NO
@property (nonatomic,assign)BOOL showDefaultCountDown;

// @param 广告位标识
- (instancetype)initWithPlaceId:(NSString *)placeId;

//加载广告
- (void)loadAds;

//前贴广告时长 -- 当倒计时回调出现时,获取的总时间才准确 单位s
- (NSInteger)getAllAdDuration;


@end

NS_ASSUME_NONNULL_END
