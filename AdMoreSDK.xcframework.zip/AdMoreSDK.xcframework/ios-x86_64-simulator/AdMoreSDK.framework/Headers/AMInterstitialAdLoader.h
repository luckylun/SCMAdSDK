//
//  AMInterstitialAdLoader.h
//  AdMoreSDK
//
//  Created by Aaron on 2021/5/16.
//

#import <Foundation/Foundation.h>
#import "AMInterstitialAdLoaderDelegate.h"

NS_ASSUME_NONNULL_BEGIN

//插屏
@interface AMInterstitialAdLoader : NSObject
/// 代理指针
@property (nonatomic, weak)id<AMInterstitialAdLoaderDelegate> delegate;

/// 初始化广告
/// @param placeId 广告位
- (instancetype)initWithPlaceId:(NSString *)placeId;

/// 获取广告
- (void)loadAd;

/**
 *  必须传入用于显示插播广告的UIViewController
 */
@property (nonatomic,weak)UIViewController * viewController;

/**
 *  广告展示方法
 *  详解：[必选]发起展示广告请求, 必须传入用于显示插播广告的UIViewController
 */

- (void)presentAdFromRootViewController:(UIViewController *)rootViewController;

/**
 *  非 WiFi 网络，是否自动播放。默认 NO。loadAd 前设置。
 */

@property (nonatomic, assign) BOOL videoAutoPlayOnWWAN;

/**
 *  自动播放时，是否静音。默认 YES。loadAd 前设置。
 */
@property (nonatomic, assign) BOOL videoMuted;

/**
 *  视频详情页播放时是否静音。默认NO。loadAd 前设置。
 */
@property (nonatomic, assign) BOOL detailPageVideoMuted;

/**
 * 是否是视频插屏2.0广告
 */
@property (nonatomic, assign, readonly) BOOL isVideoAd;

/**
 * 视频插屏广告时长，单位 ms
 */
- (CGFloat)videoDuration;

/**
 * 视频插屏广告已播放时长，单位 ms
 */
- (CGFloat)videoPlayTime;
@end

NS_ASSUME_NONNULL_END
