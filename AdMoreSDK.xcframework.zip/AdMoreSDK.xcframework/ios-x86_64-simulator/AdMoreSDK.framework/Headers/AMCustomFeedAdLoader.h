//
//  AMCustomFeedAdLoader.h
//  AdMoreSDK
//
//  Created by Aaron on 2021/5/16.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@class AMNativeAdDataObject;

@protocol AMCustomFeedAdLoaderDelegate <NSObject>

/**
 广告数据回调

 @param nativeAdDataObjects 广告数据数组
 @param error 错误信息
 */
- (void)am_nativeFeedAdLoaded:(NSArray<AMNativeAdDataObject *> * _Nullable)nativeAdDataObjects error:(NSError * _Nullable)error;

@end


@interface AMCustomFeedAdLoader : NSObject

/// 代理指针
@property (nonatomic, weak)id<AMCustomFeedAdLoaderDelegate> delegate;

/// 初始化广告
/// @param placeId 广告类型
- (instancetype)initWithPlaceId:(NSString *)placeId;

/// 获取广告
- (void)loadAd;

@end

NS_ASSUME_NONNULL_END
