//
//  AdMoreSDKDefines.h
//  AdMoreSDK
//
//  Created by Aaron on 2021/5/16.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "FunSDKDefines.h"


NS_ASSUME_NONNULL_BEGIN

@interface AdMoreSDKDefines : FunSDKDefines

@end

NS_ASSUME_NONNULL_END
