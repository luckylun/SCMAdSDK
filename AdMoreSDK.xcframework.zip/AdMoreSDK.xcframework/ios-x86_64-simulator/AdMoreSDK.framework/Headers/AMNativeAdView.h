//
//  AMNativeAdView.h
//  AdMoreSDK
//
//  Created by Aaron on 2021/5/16.
//

#import <UIKit/UIKit.h>
#import "AMNativeAdDataObject.h"
#import "AdMoreSDKDefines.h"

NS_ASSUME_NONNULL_BEGIN

@class AMNativeAdView;

@protocol AMNativeAdViewDelegate <NSObject>

@optional
/**
 广告曝光回调

 @param nativeAdView AMNativeAdView 实例
 */
- (void)am_nativeAdViewWillExpose:(AMNativeAdView *)nativeAdView;


/**
 广告点击回调

 @param nativeAdView AMNativeAdView 实例
 */
- (void)am_nativeAdViewDidClick:(AMNativeAdView *)nativeAdView;


/**
 广告详情页关闭回调

 @param nativeAdView AMNativeAdView 实例
 */
- (void)am_nativeAdDetailViewClosed:(AMNativeAdView *)nativeAdView;


/**
 当点击应用下载或者广告调用系统程序打开时调用
 
 @param nativeAdView AMNativeAdView 实例
 */
- (void)am_nativeAdViewApplicationWillEnterBackground:(AMNativeAdView *)nativeAdView;


/**
 广告详情页面即将展示回调

 @param nativeAdView AMNativeAdView 实例
 */
- (void)am_nativeAdDetailViewWillPresentScreen:(AMNativeAdView *)nativeAdView;


/**
 视频广告播放状态更改回调

 @param nativeAdView AMNativeAdView 实例
 @param status 视频广告播放状态
 @param userInfo 视频广告信息
 */
- (void)am_nativeAdView:(AMNativeAdView *)nativeAdView playerStatusChanged:(FSMediaPlayerStatus)status userInfo:(NSDictionary *)userInfo;

/**
 播放完成回调

 @param mediaView 播放器实例
 */
- (void)am_nativeAdMediaViewDidPlayFinished:(UIView *)mediaView;

@end




@interface AMNativeAdView : UIView

// 设置视频广告是否静音 默认为YES  userControlEnable
@property (nonatomic,assign)BOOL videoMuted;

/*
 是否支持用户点击 MediaView 改变视频播放暂停状态，默认 YES
 设为 YES 时，用户点击会切换播放器播放、暂停状态
 */
@property (nonatomic,assign)BOOL userControlEnable;

/**
 视频广告的媒体View，绑定数据对象后自动生成，可自定义布局
 */
@property (nonatomic, strong, readonly) UIView *mediaView;

/**
 腾讯广告 LogoView，自动生成，可自定义布局
 */
@property (nonatomic, strong, readonly) UIView *logoView;

/**
 广告 View 时间回调对象
 */
@property (nonatomic, weak) id<AMNativeAdViewDelegate> delegate;

/*
 *  viewControllerForPresentingModalView
 *  详解：开发者需传入用来弹出目标页的ViewController，一般为当前ViewController
 */
@property (nonatomic, weak) UIViewController *viewController;

/**
 @param dataObject 视图绑定的数据对象
 @param clickableViews 可点击的视图数组，此数组内的广告元素才可以响应广告对应的点击事件
 */
- (void)registerDataObject:(AMNativeAdDataObject *)dataObject ClickableViews:(NSArray<UIView *> *)clickableViews;


/**
 注销数据对象，在 tableView、collectionView 等场景需要复用 AMNativeAdView 时，
 需要在合适的时机，例如 cell 的 prepareForReuse 方法内执行 unregisterDataObject 方法，
 将广告对象与 AMNativeAdView 解绑，具体可参考示例 demo 的 NativeAdBaseTableViewCell 类
 */
- (void)unregisterDataObject;

@end

NS_ASSUME_NONNULL_END
