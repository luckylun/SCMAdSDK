//
//  AdMoreBanner.h
//  AdMoreSDK
//
//  Created by Aaron on 2021/5/18.
//

#import <UIKit/UIKit.h>

@class AdMoreBanner;

NS_ASSUME_NONNULL_BEGIN

@protocol AdMoreBannerDelegate <NSObject>

@optional


/// 广告加载成功
/// @param bannerView bannerView
- (void)am_adBannerViewDidLoad:(AdMoreBanner *)bannerView;

/// 广告加载失败
/// @param bannerView bannerView
/// @param error 失败信息
- (void)am_adBannerViewFailedToLoad:(AdMoreBanner *)bannerView error:(NSError *)error;

/// 广告曝光
/// @param bannerView bannerView
- (void)am_adBannerViewWillExpose:(AdMoreBanner *)bannerView;

/// 广告被点击
/// @param bannerView bannerView
- (void)am_adBannerViewClicked:(AdMoreBanner *)bannerView;

/// 广告被用户主动关闭
/// @param bannerView bannerView
- (void)am_adBannerViewWillClose:(AdMoreBanner *)bannerView;

@end

@interface AdMoreBanner : UIView

/// 实例化方法
/// @param frame 广告位置和大小
/// @param placementId 广告位Id
/// @param viewController 视图控制器
+ (instancetype)initWithFrame:(CGRect)frame
                  placementId:(NSString *)placementId
               viewController:(UIViewController *)viewController;

@property (nonatomic,weak)id<AdMoreBannerDelegate>delegate;

/// 请求并展示广告
- (void)loadAd;

@end

NS_ASSUME_NONNULL_END
