//
//  AMInterstitialAdLoaderDelegate.h
//  AdMoreSDK
//
//  Created by Aaron on 2021/5/16.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "AdMoreSDKDefines.h"

NS_ASSUME_NONNULL_BEGIN

// 插屏广告回调
@class AMInterstitialAdLoader;

@protocol AMInterstitialAdLoaderDelegate <NSObject>

@optional
/**
 *  插屏2.0广告预加载成功回调
 *  当接收服务器返回的广告数据成功且预加载后调用该函数
 */
- (void)am_interstitialSuccessToLoadAd:(AMInterstitialAdLoader *_Nullable)interstitialAd;

/**
 *  插屏2.0广告预加载失败回调
 *  当接收服务器返回的广告数据失败后调用该函数
 */
- (void)am_interstitialFailToLoadAd:(AMInterstitialAdLoader *_Nullable)interstitialAd error:(NSError *_Nullable)error;

/**
 *  插屏2.0广告将要展示回调
 *  插屏2.0广告即将展示回调该函数
 */
- (void)am_interstitialWillPresentScreen:(AMInterstitialAdLoader *_Nullable)interstitialAd;

/**
 *  插屏2.0广告视图展示成功回调
 *  插屏2.0广告展示成功回调该函数
 */
- (void)am_interstitialDidPresentScreen:(AMInterstitialAdLoader *_Nullable)unifiedInterstitial;

/**
 *  插屏2.0广告视图展示失败回调
 *  插屏2.0广告展示失败回调该函数
 */
- (void)am_interstitialFailToPresent:(AMInterstitialAdLoader *_Nullable)interstitialAd error:(NSError *_Nullable)error;

/**
 *  插屏2.0广告展示结束回调
 *  插屏2.0广告展示结束回调该函数
 */
- (void)am_interstitialDidDismissScreen:(AMInterstitialAdLoader *_Nullable)interstitialAd;

/**
 *  当点击下载应用时会调用系统程序打开其它App或者Appstore时回调
 */
- (void)am_interstitialWillLeaveApplication:(AMInterstitialAdLoader *_Nullable)interstitialAd;

/**
 *  插屏2.0广告曝光回调
 */
- (void)am_interstitialWillExposure:(AMInterstitialAdLoader *_Nullable)interstitialAd;

/**
 *  插屏2.0广告点击回调
 */
- (void)am_interstitialClicked:(AMInterstitialAdLoader *_Nullable)interstitialAd;

/**
 *  点击插屏2.0广告以后即将弹出全屏广告页
 */
- (void)am_interstitialAdWillPresentFullScreenModal:(AMInterstitialAdLoader *_Nullable)interstitialAd;

/**
 *  点击插屏2.0广告以后弹出全屏广告页
 */
- (void)am_interstitialAdDidPresentFullScreenModal:(AMInterstitialAdLoader *_Nullable)interstitialAd;

/**
 *  全屏广告页将要关闭
 */
- (void)am_interstitialAdWillDismissFullScreenModal:(AMInterstitialAdLoader *_Nullable)interstitialAd;

/**
 *  全屏广告页被关闭
 */
- (void)am_interstitialAdDidDismissFullScreenModal:(AMInterstitialAdLoader *_Nullable)interstitialAd;

/**
 * 插屏2.0视频广告 player 播放状态更新回调
 */
- (void)am_interstitialAd:(AMInterstitialAdLoader *_Nullable)unifiedInterstitial playerStatusChanged:(FSMediaPlayerStatus)status;

/**
 * 插屏2.0视频广告详情页 WillPresent 回调
 */
- (void)am_interstitialAdViewWillPresentVideoVC:(AMInterstitialAdLoader *_Nullable)interstitialAd;

/**
 * 插屏2.0视频广告详情页 DidPresent 回调
 */
- (void)am_interstitialAdViewDidPresentVideoVC:(AMInterstitialAdLoader *_Nullable)interstitialAd;

/**
 * 插屏2.0视频广告详情页 WillDismiss 回调
 */
- (void)am_interstitialAdViewWillDismissVideoVC:(AMInterstitialAdLoader *_Nullable)interstitialAd;

/**
 * 插屏2.0视频广告详情页 DidDismiss 回调
 */
- (void)am_interstitialAdViewDidDismissVideoVC:(AMInterstitialAdLoader *_Nullable)interstitialAd;

@end

NS_ASSUME_NONNULL_END
