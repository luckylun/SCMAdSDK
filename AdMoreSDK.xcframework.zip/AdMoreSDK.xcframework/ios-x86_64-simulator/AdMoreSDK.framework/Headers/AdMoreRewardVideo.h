//
//  AdMoreRewardVideo.h
//  AdMoreSDK
//
//  Created by Aaron on 2021/5/15.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
NS_ASSUME_NONNULL_BEGIN


@class AdMoreRewardVideo;

@protocol AdMoreRewardVideoDelegate <NSObject>

@optional
/**
 广告数据加载成功回调

 @param rewardedVideoAd AdMoreRewardVideo 实例
 */
- (void)am_rewardVideoAdDidLoad:(AdMoreRewardVideo * _Nullable)rewardedVideoAd;

/**
 视频数据下载成功回调，已经下载过的视频会直接回调

 @param rewardedVideoAd AdMoreRewardVideo 实例
 */
- (void)am_rewardVideoAdVideoDidLoad:(AdMoreRewardVideo * _Nullable)rewardedVideoAd;

/**
 视频播放页即将展示回调

 @param rewardedVideoAd AdMoreRewardVideo 实例
 */
- (void)am_rewardVideoAdWillVisible:(AdMoreRewardVideo * _Nullable)rewardedVideoAd;

/**
 视频广告曝光回调

 @param rewardedVideoAd AdMoreRewardVideo 实例
 */
- (void)am_rewardVideoAdDidExposed:(AdMoreRewardVideo *_Nullable)rewardedVideoAd;

/**
 视频播放页关闭回调

 @param rewardedVideoAd AdMoreRewardVideo 实例
 */
- (void)am_rewardVideoAdDidClose:(AdMoreRewardVideo *_Nullable)rewardedVideoAd;

/**
 视频广告信息点击回调

 @param rewardedVideoAd AdMoreRewardVideo 实例
 */
- (void)am_rewardVideoAdDidClicked:(AdMoreRewardVideo *_Nullable)rewardedVideoAd;

/**
 视频广告各种错误信息回调
 @param rewardedVideoAd AdMoreRewardVideo 实例
 @param error 具体错误信息
 */
- (void)am_rewardVideoAd:(AdMoreRewardVideo *_Nullable)rewardedVideoAd didFailWithError:(NSError *_Nullable)error;

/**
 视频广告播放达到激励条件回调

 @param rewardedVideoAd AdMoreRewardVideo 实例
 */
- (void)am_rewardVideoAdDidRewardEffective:(AdMoreRewardVideo *_Nullable)rewardedVideoAd;

/**
 视频广告视频播放完成
 @param rewardedVideoAd AdMoreRewardVideo 实例
 */
- (void)am_rewardVideoAdDidPlayFinish:(AdMoreRewardVideo *_Nullable)rewardedVideoAd;

@end

//激励视频
@interface AdMoreRewardVideo : NSObject

@property (nonatomic,assign)BOOL videoMuted;

@property (nonatomic,weak)id<AdMoreRewardVideoDelegate>delegate;

@property (nonatomic,weak)UIViewController * viewController;

- (instancetype)initWithPlaceId:(NSString *)placeId;

- (void)loadAd;

/**
 *  当广告类型为 Video时，返回视频时长，单位 ms，当广告类型为其他时，返回0
 */
- (CGFloat)videoDuration;


@end

NS_ASSUME_NONNULL_END
