//
//  AMNativeAdDataObject.h
//  AdMoreSDK
//
//  Created by Aaron on 2021/5/16.
//

#import <Foundation/Foundation.h>

@class FSNativeAdDataObject;

NS_ASSUME_NONNULL_BEGIN

@interface AMNativeAdDataObject : NSObject

/**
 广告标题
 */
@property (nonatomic, copy, readonly) NSString *title;
/**
 广告描述
 */
@property (nonatomic, copy, readonly) NSString *desc;
/**
 广告Url
 */
@property (nonatomic, copy, readonly) NSString *imageUrl;

/**
 素材宽度，代表大图 imageUrl 宽度
 */
@property (nonatomic, readonly) NSInteger imageWidth;

/**
 素材高度，代表大图 imageUrl 高度
 */
@property (nonatomic, readonly) NSInteger imageHeight;

/**
 应用类广告App 图标Url
 */
@property (nonatomic, copy, readonly) NSString *iconUrl;


/**
 是否为视频广告
 */
@property (nonatomic, readonly) BOOL isVideoAd;




@end

NS_ASSUME_NONNULL_END
