//
//  AMOutPutAdView.h
//  AdMoreSDK
//
//  Created by Aaron on 2021/5/16.
//

#import <UIKit/UIKit.h>
#import "FunSDKDefines.h"

@class AMOutPutAdView;

@protocol AMOutPutAdViewDelegate <NSObject>

@optional
/// 广告点击回调
/// @param outPutAdView 广告实体
/// @param deepLink deekLink 部分广告需要配置DeepLink打开方式,如果需要请根据deepLink自行配置,如果不是此字段将返回nil
- (void)am_unifiedNativeAdViewDidClick:(AMOutPutAdView *_Nonnull)outPutAdView isDeepLink:(NSString *_Nullable)deepLink;

/// 广告详情页面即将打开
/// @param outPutAdView 广告实体
- (void)am_unifiedNativeAdDetailViewWillPresentScreen:(AMOutPutAdView *_Nonnull)outPutAdView;

/// 广告页面关闭
/// @param outPutAdView 广告实体
- (void)am_unifiedNativeAdDetailViewClosed:(AMOutPutAdView *_Nonnull)outPutAdView;

/// 广告曝光
/// @param outPutAdView 广告实体
- (void)am_unifiedNativeAdViewWillExpose:(AMOutPutAdView *_Nonnull)outPutAdView;


/// 点击关闭按钮
/// @param outPutAdView 广告实体
- (void)am_unifiedNativeAdViewClickCloseButton:(AMOutPutAdView *_Nonnull)outPutAdView;


/// 播放完成回调
/// @param outPutAdView 广告实体
- (void)am_mediaViewDidPlayFinished:(AMOutPutAdView *_Nonnull)outPutAdView;


@end

NS_ASSUME_NONNULL_BEGIN


///模版信息流对外输出的View,请根据adMoreOutPutAdViewHeight返回高度进行设置,此外如果需要广告跳转请传入viewController字段
@interface AMOutPutAdView : UIView

- (instancetype)initWithFrame:(CGRect)frame NS_UNAVAILABLE;

- (instancetype)initWithCoder:(NSCoder *)aDecoder NS_UNAVAILABLE;

/// 代理指针（返回广告操作状态）
@property (nonatomic, weak)id<AMOutPutAdViewDelegate> delegate;

/// 开发者需要传入用来弹出目标页的ViewController,一般为当前ViewController

@property (nonatomic, weak)UIViewController *viewController;
/// 是否为视频广告
@property (nonatomic, assign, readonly) BOOL isVideoAd;
/// 如果是视频广告,则返回广告时长(单位 ms)
@property (nonatomic, assign, readonly) CGFloat duration;
/// 返回视图高度
- (CGFloat)adMoreOutPutAdViewHeight;

/// 设置视图
- (void)addShowView:(UIView *)indexView;
@end

NS_ASSUME_NONNULL_END
